// Global Variable
const mode = "RELEASE";
const dashboardUrl =
  mode == "TESTING"
    ? "https://test.clisha.me/dashboard/" //"http://localhost:3000/dashboard/"
    : "https://clisha.me/dashboard/";

    let task,
    step = null,
    active_modal,
    question_modal,
    toggle_modal,
    clisha_search = {},
    currentJourney = {};
  
  let domain = window.location.href,
    currentUrl = window.location;
  domain = domain
    .replace("http://", "")
    .replace("https://", "")
    .replace("www.", "")
    .split(/[/?#]/);
  
  const google_url = "google.com",
    youtube_url = "youtube.com",
    tiktok_url = "tiktok.com";
  
  // Silent Clisha extension if neccesary
  function silentClishaExtension() {
    const allowedDomains = ["clisha.me", "clisha.com", "clisha.io"];
    
    const domain = window.location.hostname.split('.').slice(-2).join('.');
    if (allowedDomains.includes(domain)) return true;
   
    return false;
  }
  
  // Sync Task with Backround
  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    // Start Extension
    if (message.form == true) return handleNextJourney();
  
    if (message.vid_completed == true) {
      if (task?.task_type == "journey" || task?.task_type == "search_journey") {
        return handleNextJourney();
      } else {
        return completeExtensionTask();
      }
    }
  
    if (message.appChange == true) {
      const result = await someAsyncOperation();
      return sendResponse({ response: result });
    }
  
    // Silent Extension in some url
    const isSilent = silentClishaExtension();
  
    if (!isSilent) {
      task = message.task;
      step = message.step;
      if (
        task?.task_type == "google_search" ||
        task?.task_type == "search_journey"
      )
        activateClishaSearch();
      if (task?.task_type == "journey") activateJourneyTask();
    }
  });
  
  // Run available task in the store
  chrome.storage.sync.get(null, (item) => {
    if (Object.keys(item).length) {
      // Start Extension
      const isSilent = silentClishaExtension();
      if (!isSilent) {
        task = item.task;
        step = item.step;
        if (
          task?.task_type == "google_search" ||
          task?.task_type == "search_journey"
        )
          activateClishaSearch();
        if (task?.task_type == "journey") activateJourneyTask();
      }
      return true;
    }
  });
  
  async function someAsyncOperation() {
    return new Promise((resolve) => {
      setTimeout(() => {
        reloadClishaTask();
        resolve();
      }, 1000);
    });
  }
  
  function reloadClishaTask() {
    if (task?.task_type == "google_search" || task?.task_type == "search_journey")
      activateClishaSearch();
    if (task?.task_type == "journey") activateJourneyTask();
    // return true;
  }
  
  // Get id from youtube for match up
  function getIdFromUrl(url) {
    try {
      if (url.includes("youtu.be")) {
        return url.split("youtu.be/")[1];
      } else if (url.includes("youtube.com")) {
        url = "https://" + url;
        let urlObj = new URL(url);
        return urlObj.searchParams.get("v");
      }
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "https://" + url;
        return url;
      }
    } catch (error) {
      // console.error("Invalid URL: ", url);
      return null;
    }
  }
  
  // Confirm if given link match up
  function handshake(link, type = "default") {
    let result, webpage;
    if (type == "default") {
      webpage = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      let currentLink = currentUrl.href.replace(
        /^(http:\/\/|https:\/\/|www\.)/,
        ""
      );
      let linkId = getIdFromUrl(webpage);
      let currentId = getIdFromUrl(currentLink);
      result = currentId.includes(linkId);
    }
  
    if (type == "journey") {
      let webpage = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      let currentLink = currentUrl.href.replace(
        /^(http:\/\/|https:\/\/|www\.)/,
        ""
      );
      result = currentLink.includes(webpage);
    }
  
    if (type == "tiktok") {
      page = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "").split(/[/?#]/);
  
      result = domain[3] == page[3];
    }
  
    return result;
  }
  
  function activateClishaSearch() {
    clisha_search =
      typeof task.google_search === "string"
        ? task.google_search
        : task.google_search;
    let advance_type = task.advance_type;
    const videos = ["youtube", "tiktok"];
  
    // Run Google related task
    if (!videos.includes(advance_type)) runGoogleSearch();
  
    if (advance_type == "youtube") runYoutubeSearch();
  
    if (advance_type == "tiktok") runTiktokSearch();
  }
  
  // Track Tiktok
  function trackExternalVideo() {
    let video = document.getElementsByTagName("video")[0];
    initExternalVideo(video);
  }
  
  async function activateJourneyTask() {
    let journeyTask = task.journey;
    let gottenStep = await getCurrentStep();
    step = gottenStep;
    currentJourney = journeyTask[0];
  
    if (gottenStep <= 1 && handshake(currentJourney.link)) {
      if (gottenStep == 0) chrome.storage.sync.set({ step: gottenStep + 1 });
      gottenStep = 1;
      runJourneyInteraction();
    } else if (gottenStep > 1) {
      currentJourney = task.journey[gottenStep - 1];
      if (handshake(currentJourney.link)) {
        runJourneyInteraction();
      } else {
        showModal(2, {
          error: true,
          head: `You have entered a wrong page! Please visit "${currentJourney.link}" to continue.`,
          image: 'error',
        });
      }
    } else {
      showModal(2, {
        error: true,
        head: `You have clicked on the wrong page! Please visit "${currentJourney.link}" to continue.`,
        image: 'error',
      });
    }
  }
  
  async function activateSearchJourneyTask() {
    // const currentUrl = window.location;
    currentJourney = task.journey[0];
    let clisha_search = task.google_search;
    let links = [currentJourney.link, currentJourney.link + "?completed=vid"];
    let gottenStep = await getCurrentStep();
    step = gottenStep;
    if (gottenStep <= 1 && handshake(currentJourney.link)) {
      if (gottenStep == 0) chrome.storage.sync.set({ step: gottenStep + 1 });
      gottenStep = 1;
      activateJourneyTask();
    } else if (gottenStep > 1) {
      currentJourney = task.journey[gottenStep - 1];
      activateJourneyTask();
    } else {
      showModal(2, {
        error: true,
        head: `You have clicked on the wrong page! Please go back to Google search result and click on  "${clisha_search.title}"`,
        image: 'error',
      });
    }
  }
  
  const getCurrentStep = () => {
    return new Promise((resolve) => {
      chrome.storage.sync.get("step", (item) => {
        if (Object.keys(item).length) {
          let currentStep = item.step;
          resolve(currentStep ? currentStep : 1);
        } else {
          resolve(1);
        }
      });
    });
  };
  
  function runJourneyInteraction() {
    let start =
      step == 1
        ? "Great! Let's go,"
        : step == task.journey.length
        ? "Great! Almost done,"
        : "Let's continue";
    let type = "",
      question = null,
      interaction = null;
  
    if (currentJourney.link_type == "video") {
      type =
        "Kindly watch the video on this page. Watch up to 70% of the video to complete this step. Thanks ";
    }
  
    if (currentJourney.link_type == "form") {
      type = "Kindly fill the form on this page to complete this step. Thanks ";
      initiateJourneyForm(currentJourney.link);
    }
  
    if (currentJourney.link_type == "content") {
      question = currentJourney.step_interaction.question;
      interaction = currentJourney.step_interaction;
      if (
        (interaction && interaction.interaction_type == "multichoice") ||
        interaction.interaction_type == "multistep"
      ) {
        type =
          "Please Read the question below. You will find the answer on this Page! For answering it click on the button in the bottom right hand corner.";
        multiChoiceJourney();
      } else {
        type = `You have clicked on the right page! Please interact with this page until the timer runs out`;
        timerInteraction();
      }
    }
  
    return showModal(1, { step, head: start, body: type, question, interaction, image: 'icon' });
  }
  
  // Task Functionalities
  async function showModal(open = 1, content = {}) {
    let template = `/templates/modal${open}.html`,
      modalId = `#clishaModelId${open}`;
    let element = document.querySelector(modalId);
    if (element) element.remove();
  
    fetch(chrome.runtime.getURL(template))
      .then((r) => r.text())
      .then((html) => {
        document.body.insertAdjacentHTML("beforeend", html);
        active_modal = document.querySelector(modalId);
        if (content) {
          let entry = document.querySelector("#boost-entry"),
            error = document.querySelector("#boost-error");
  
          if (content.step) {
            let stepElem = document.createElement("h4");
            stepElem.innerHTML = `Step ${content.step} of  ${task.journey.length}`;
            entry.appendChild(stepElem);
          }
  
          if (content.head) {
            let headerElem = document.createElement("h5");
            headerElem.innerHTML = content.head;
            entry.appendChild(headerElem);
          }
  
          if (content.body) {
            let paramElem = document.createElement("p");
            paramElem.innerHTML = content.body;
            entry.appendChild(paramElem);
          }
          
          if(content.image){
            const imgUrl = chrome.runtime.getURL(`/images/${content.image}.png`);
            document.getElementById(`clisha_image${open}`).src = imgUrl;
          }
  
          // Add Question Interaction preview panel to modal
          if (content.question) {
            let options = document.querySelector("#task-options-preview");
            questionElem = document.createElement("h4");
            questionElem.innerHTML = content.question;
            entry.appendChild(questionElem);
            task.interaction = content.interaction
              ? content.interaction
              : task.interaction;
  
            let option1, option2, option3, option4, option5;
            option1 = document.createElement("li");
            option2 = document.createElement("li");
  
            if (task.interaction) {
              option1.innerHTML = task.interaction.option1;
              option2.innerHTML = task.interaction.option2;
              options.append(option1, option2);
              if (task.interaction.option3) {
                option3 = document.createElement("li");
                option3.innerHTML = task.interaction.option3;
                options.appendChild(option3);
              }
              if (task.interaction.option4) {
                option4 = document.createElement("li");
                option4.innerHTML = task.interaction.option4;
                options.appendChild(option4);
              }
              if (task.interaction.option5) {
                option5 = document.createElement("li");
                option5.innerHTML = task.interaction.option5;
                options.appendChild(option5);
              }
            }
          }
  
          if (content.error) {
            entry.style.display = content.error ? "none" : "block";
            error.style.display = content.error ? "block" : "none";
          }
        }
  
        active_modal.classList.add("clisha_modal_open");
      });
  }
  
  function parseQueryParam(url) {
    var query = {};
    var pairs = (url[0] === "?" ? url.substr(1) : url).split("&");
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split("=");
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
    }
    return query;
  }
  
  function initiateJourneyForm(link) {
    chrome.runtime.sendMessage({ trackForm: link }, (response) => {});
  }
  
  function timerInteraction() {
    let timer = `/templates/interaction_timer.html`;
  
    fetch(chrome.runtime.getURL(timer))
      .then((r) => r.text())
      .then((html) => {
        document.body.insertAdjacentHTML("beforeend", html);
  
        let warning = document.getElementById("clisha_warning");
        let clisha_timer = document.getElementById("clisha_timer");
  
        // let timeValue = task?.interaction ? task.interaction.duration : 45;
        let timeValue = task?.google_search?.duration
          ? task?.google_search?.duration
          : task?.website_click?.duration
          ? task?.website_click?.duration
          : 45;
  
        if (Object.keys(currentJourney).length > 0) {
          //is journey task
          timeValue = currentJourney?.step_interaction
            ? currentJourney.step_interaction.duration
            : 45;
        }
  
        let intervalId = setInterval(() => {
          let currentTab = window.location.href;
          let url = task.url ? task.url : "";
          if (Object.keys(currentJourney).length > 0) {
            //is journey task
            url = currentJourney.link;
          }
          if (handshake(url) && document.visibilityState === "visible") {
            timeValue--;
            warning.innerText = "Hello! Do not close or leave this window ";
            clisha_timer.innerText = timeValue;
            if (timeValue == 0) {
              clearInterval(intervalId);
              if (
                task?.task_type == "journey" ||
                task?.task_type == "search_journey"
              ) {
                return handleNextJourney();
              } else {
                return completeExtensionTask();
              }
            }
          }
        }, 1000);
      });
  }
  
  function multiChoiceInteraction() {
    const multichoice = `/templates/interaction_multichoice.html`;
    fetch(chrome.runtime.getURL(multichoice))
      .then((r) => r.text())
      .then((html) => {
        document.body.insertAdjacentHTML("beforeend", html);
        let question = document.querySelector("#multichoice-question"),
          option1 = document.querySelector("#option1"),
          option2 = document.querySelector("#option2"),
          option3 = document.querySelector("#option3"),
          option4 = document.querySelector("#option4"),
          option5 = document.querySelector("#option5");
  
        question.innerHTML = task.interaction.question;
        option1.innerHTML = task.interaction.option1;
        option2.innerHTML = task.interaction.option2;
  
        if (task.interaction.option3) {
          document.querySelector(".option3").style.display = "block";
          option3.innerHTML = task.interaction.option3;
        }
        if (task.interaction.option4) {
          document.querySelector(".option4").style.display = "block";
          option4.innerHTML = task.interaction.option4;
        }
        if (task.interaction.option5) {
          document.querySelector(".option5").style.display = "block";
          option5.innerHTML = task.interaction.option5;
        }
      });
  }
  
  function multiChoiceJourney() {
    let multichoice = `/templates/interaction_multichoice.html`;
    fetch(chrome.runtime.getURL(multichoice))
      .then((r) => r.text())
      .then((html) => {
        document.body.insertAdjacentHTML("beforeend", html);
        let question = document.querySelector("#multichoice-question"),
          option1 = document.querySelector("#option1"),
          option2 = document.querySelector("#option2"),
          option3 = document.querySelector("#option3"),
          option4 = document.querySelector("#option4"),
          option5 = document.querySelector("#option5");
        
        let options = [option1, option2, option3, option4, option5];

        question.innerHTML = currentJourney.step_interaction.question;
        option1.innerHTML = currentJourney.step_interaction.option1;
        option2.innerHTML = currentJourney.step_interaction.option2;
  
        if (currentJourney.step_interaction.option3) {
          document.querySelector(".option3").style.display = "block";
          option3.innerHTML = currentJourney.step_interaction.option3;
        }
        if (currentJourney.step_interaction.option4) {
          document.querySelector(".option4").style.display = "block";
          option4.innerHTML = currentJourney.step_interaction.option4;
        }
        if (currentJourney.step_interaction.option5) {
          document.querySelector(".option5").style.display = "block";
          option5.innerHTML = currentJourney.step_interaction.option5;
        }

        options.forEach((option, index) => {
            let radioBtn = document.querySelector(`#option${index + 1}-radio`);
            if (radioBtn) {
                radioBtn.addEventListener("change", function() {
                    // Reset previous selected options
                    options.forEach((opt) => opt.classList.remove("selected"));

                    // Add 'selected' class to the clicked option
                    option.classList.add("selected");

                    // Enable submit button once an option is selected
                    document.querySelector("#clisha-submit-answer").disabled = false;
                });
            }
        });
      });
  }
  
  function completeExtensionTask() {
    chrome.storage.sync.clear(function () {
      const url = `${dashboardUrl}reward?t=${task.id}&p=${task.points}&c=${task?.interaction_b ? 20 : 10}&status=done&b=${task?.bonus_points}`;
      chrome.runtime.sendMessage({ completed: "true" }, (response) => {});
      const features = "right=100,top=100,width=600,height=450";
      window.open(url, "_blank", features);
  
      const overlay = document.querySelector(".clisha_overlay"),
        float = document.querySelectorAll(".clisha_float");
  
      if (float.length) {
        float.forEach((f) => {
          f.style.display = "none";
        });
      }
  
      if (overlay) overlay.style.display = "none";
  
      var error = chrome.runtime.lastError;
      if (error) console.error(error);
      throw error;
    });
  }

  chrome.runtime.sendMessage({ test: "activate" }, response => {
    console.log(response?.status || "No response from service worker.");
  });
  