# clicha-chrome-ext


npm install


#Note: there is no git ignore because we need all the file used in the folder

New Feature: Task Reporting Form
Users can now report issues directly through the extension using the built-in task report form.

Accessible from the extension popup or task page.

Allows users to submit concerns or flag problems with specific tasks.

Helps improve task quality and user experience.

📌 Reports are securely sent to the backend for review and resolution.