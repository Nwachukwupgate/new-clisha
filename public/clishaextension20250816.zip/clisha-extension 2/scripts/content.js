// Global Variable
const mode = "RELEASE";
// const mode = "DEVELOPMENT"
const dashboardUrl =
  mode === "RELEASE"
    ? "https://clisha.me/dashboard/"
    : "https://dev.clisha.me/dashboard/";

let task,
  step = null,
  active_modal,
  question_modal,
  toggle_modal,
  active_modal1,
  clisha_search = {},
  currentJourney = {};

let domain = window.location.href,
  currentUrl = window.location;
domain = domain
  .replace("http://", "")
  .replace("https://", "")
  .replace("www.", "")
  .split(/[/?#]/);

const google_url = "google.com",
  youtube_url = "youtube.com",
  tiktok_url = "tiktok.com";

// Silent Clisha extension if neccesary
function silentClishaExtension() {
  const allowedDomains = ["clisha.me", "clisha.com", "clisha.io"];

  const domain = window.location.hostname.split('.').slice(-2).join('.');
  if (allowedDomains.includes(domain)) return true;

  return false;
}

// Sync Task with Background - FIXED MESSAGE HANDLING
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  try {
    // Handle form submission
    if (message.form === true) {
      handleNextJourney();
      sendResponse({ received: true });
      return true;
    }

    // Handle video completion
    if (message.vid_completed === true) {
      if (task?.task_type === "journey" || task?.task_type === "search_journey") {
        handleNextJourney();
      } else {
        completeExtensionTask();
      }
      sendResponse({ received: true });
      return true;
    }

    // Handle app change - FIXED ASYNC HANDLING
    if (message.appChange === true) {
      try {
        const result = await someAsyncOperation();
        sendResponse({ response: result });
      } catch (error) {
        console.error("Error in appChange handler:", error);
        sendResponse({ error: error.message });
      }
      return true; // Keep message channel open for async response
    }

    // Handle task assignment
    if (message.task && message.step !== undefined) {
      const isSilent = silentClishaExtension();

      if (!isSilent) {
        task = message.task;
        step = message.step;

        if (task?.task_type === "google_search" || task?.task_type === "search_journey") {
          activateClishaSearch();
        }
        if (task?.task_type === "journey") {
          activateJourneyTask();
        }
      }
      sendResponse({ received: true });
      return true;
    }

    // Default response for unhandled messages
    sendResponse({ received: false });
    return true;
  } catch (error) {
    console.error("Error in message listener:", error);
    sendResponse({ error: error.message });
    return true;
  }
});

// Run available task in the store - FIXED CALLBACK HANDLING
chrome.storage.sync.get(null, (item) => {
  try {
    if (Object.keys(item).length) {
      const isSilent = silentClishaExtension();
      if (!isSilent) {
        task = item.task;
        step = item.step;

        if (task?.task_type === "google_search" || task?.task_type === "search_journey") {
          activateClishaSearch();
        }
        if (task?.task_type === "journey") {
          activateJourneyTask();
        }
      }
    }
  } catch (error) {
    console.error("Error loading stored task:", error);
  }
});

// FIXED ASYNC OPERATION
async function someAsyncOperation() {
  return new Promise((resolve) => {
    setTimeout(() => {
      try {
        reloadClishaTask();
        resolve({ success: true });
      } catch (error) {
        resolve({ success: false, error: error.message });
      }
    }, 1000);
  });
}

function reloadClishaTask() {
  try {
    if (task?.task_type === "google_search" || task?.task_type === "search_journey") {
      activateClishaSearch();
    }
    if (task?.task_type === "journey") {
      activateJourneyTask();
    }
  } catch (error) {
    console.error("Error reloading task:", error);
  }
}

// FIXED URL PARSING - CSP SAFE
function getIdFromUrl(url) {
  try {
    if (!url) return null;

    if (url.includes("youtu.be")) {
      return url.split("youtu.be/")[1];
    } else if (url.includes("youtube.com")) {
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "https://" + url;
      }
      const urlObj = new URL(url);
      return urlObj.searchParams.get("v");
    }

    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = "https://" + url;
    }
    return url;
  } catch (error) {
    console.error("Invalid URL: ", url, error);
    return null;
  }
}

// Confirm if given link match up
function handshake(link, type = "default") {
  try {
    let result, webpage;

    if (type === "default") {
      webpage = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      let currentLink = currentUrl.href.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      let linkId = getIdFromUrl(webpage);
      let currentId = getIdFromUrl(currentLink);
      result = currentId && linkId && currentId.includes(linkId);
    }

    if (type === "journey") {
      let webpage = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      let currentLink = currentUrl.href.replace(/^(http:\/\/|https:\/\/|www\.)/, "");
      result = currentLink.includes(webpage);
    }

    if (type === "tiktok") {
      let page = link.replace(/^(http:\/\/|https:\/\/|www\.)/, "").split(/[/?#]/);
      result = domain[3] === page[3];
    }

    return result;
  } catch (error) {
    console.error("Error in handshake:", error);
    return false;
  }
}

function activateClishaSearch() {
  try {
    clisha_search = typeof task.google_search === "string"
      ? task.google_search
      : task.google_search;
    let advance_type = task.advance_type;
    const videos = ["youtube", "tiktok"];

    // Run Google related task
    if (!videos.includes(advance_type)) {
      runGoogleSearch();
    }

    if (advance_type === "youtube") {
      runYoutubeSearch();
    }

    if (advance_type === "tiktok") {
      runTiktokSearch();
    }
  } catch (error) {
    console.error("Error activating Clisha search:", error);
  }
}

// Track Tiktok
function trackExternalVideo() {
  try {
    let video = document.getElementsByTagName("video")[0];
    if (video) {
      initExternalVideo(video);
    }
  } catch (error) {
    console.error("Error tracking external video:", error);
  }
}

async function activateJourneyTask() {
  try {
    let journeyTask = task.journey;
    let gottenStep = await getCurrentStep();
    step = gottenStep;
    currentJourney = journeyTask[0];

    if (gottenStep <= 1 && handshake(currentJourney.link)) {
      if (gottenStep === 0) {
        chrome.storage.sync.set({ step: gottenStep + 1 });
      }
      gottenStep = 1;
      runJourneyInteraction();
    } else if (gottenStep > 1) {
      currentJourney = task.journey[gottenStep - 1];
      if (handshake(currentJourney.link)) {
        runJourneyInteraction();
      } else {
        showModal(2, {
          error: true,
          head: `You have entered a wrong page! Please visit "${currentJourney.link}" to continue.`,
          image: 'error',
        });
      }
    } else {
      showModal(2, {
        error: true,
        head: `You have clicked on the wrong page! Please visit "${currentJourney.link}" to continue.`,
        image: 'error',
      });
    }
  } catch (error) {
    console.error("Error activating journey task:", error);
  }
}

async function activateSearchJourneyTask() {
  try {
    currentJourney = task.journey[0];
    let clisha_search = task.google_search;
    let gottenStep = await getCurrentStep();
    step = gottenStep;

    if (gottenStep <= 1 && handshake(currentJourney.link)) {
      if (gottenStep === 0) {
        chrome.storage.sync.set({ step: gottenStep + 1 });
      }
      gottenStep = 1;
      activateJourneyTask();
    } else if (gottenStep > 1) {
      currentJourney = task.journey[gottenStep - 1];
      activateJourneyTask();
    } else {
      showModal(2, {
        error: true,
        head: `You have clicked on the wrong page! Please go back to Google search result and click on "${clisha_search.title}"`,
        image: 'error',
      });
    }
  } catch (error) {
    console.error("Error activating search journey task:", error);
  }
}

const getCurrentStep = () => {
  return new Promise((resolve) => {
    chrome.storage.sync.get("step", (item) => {
      try {
        if (Object.keys(item).length) {
          let currentStep = item.step;
          resolve(currentStep ? currentStep : 1);
        } else {
          resolve(1);
        }
      } catch (error) {
        console.error("Error getting current step:", error);
        resolve(1);
      }
    });
  });
};

function runJourneyInteraction() {
  try {
    let start = step === 1
      ? "Great! Let's go,"
      : step === task.journey.length
        ? "Great! Almost done,"
        : "Let's continue";

    let type = "",
      question = null,
      interaction = null;

    if (currentJourney.link_type === "video") {
      type = "Kindly watch the video on this page. Watch up to 70% of the video to complete this step. Thanks ";
    }

    if (currentJourney.link_type === "form") {
      type = "Kindly fill the form on this page to complete this step. Thanks ";
      initiateJourneyForm(currentJourney.link);
    }

    if (currentJourney.link_type === "content") {
      question = currentJourney.step_interaction.question;
      interaction = currentJourney.step_interaction;

      if ((interaction && interaction.interaction_type === "multichoice") ||
        interaction.interaction_type === "multistep") {
        type = "Please Read the question below. You will find the answer on this Page! For answering it click on the button in the bottom right hand corner.";
        multiChoiceJourney();
      } else {
        type = `You have clicked on the right page! Please interact with this page until the timer runs out`;
        timerInteraction();
      }
    }

    return showModal(1, { step, head: start, body: type, question, interaction, image: 'icon' });
  } catch (error) {
    console.error("Error running journey interaction:", error);
  }
}

// Task Functionalities - ENHANCED ERROR HANDLING
async function showModal(open = 1, content = {}) {
  try {
    let template = `/templates/modal${open}.html`,
      modalId = `#clishaModelId${open}`;

    let element = document.querySelector(modalId);
    if (element) element.remove();

    const response = await fetch(chrome.runtime.getURL(template));
    const html = await response.text();

    document.body.insertAdjacentHTML("beforeend", html);
    active_modal = document.querySelector(modalId);

    if (content) {
      let entry = document.querySelector("#boost-entry"),
        error = document.querySelector("#boost-error");

      if (content.step) {
        let stepElem = document.createElement("h4");
        stepElem.innerHTML = `Step ${content.step} of ${task.journey.length}`;
        entry.appendChild(stepElem);
      }

      if (content.head) {
        let headerElem = document.createElement("h5");
        headerElem.innerHTML = content.head;
        entry.appendChild(headerElem);
      }

      if (content.body) {
        let paramElem = document.createElement("p");
        paramElem.innerHTML = content.body;
        entry.appendChild(paramElem);
      }

      if (content.image) {
        const imgUrl = chrome.runtime.getURL(`/images/${content.image}.png`);
        const imgElement = document.getElementById(`clisha_image${open}`);
        if (imgElement) {
          imgElement.src = imgUrl;
        }
      }

      // Add Question Interaction preview panel to modal
      if (content.question) {
        let options = document.querySelector("#task-options-preview");
        let questionElem = document.createElement("h4");
        questionElem.innerHTML = content.question;
        entry.appendChild(questionElem);

        task.interaction = content.interaction ? content.interaction : task.interaction;

        if (task.interaction && options) {
          let option1 = document.createElement("li");
          let option2 = document.createElement("li");

          option1.innerHTML = task.interaction.option1;
          option2.innerHTML = task.interaction.option2;
          options.append(option1, option2);

          if (task.interaction.option3) {
            let option3 = document.createElement("li");
            option3.innerHTML = task.interaction.option3;
            options.appendChild(option3);
          }
          if (task.interaction.option4) {
            let option4 = document.createElement("li");
            option4.innerHTML = task.interaction.option4;
            options.appendChild(option4);
          }
          if (task.interaction.option5) {
            let option5 = document.createElement("li");
            option5.innerHTML = task.interaction.option5;
            options.appendChild(option5);
          }
        }
      }

      if (content.error) {
        if (entry) entry.style.display = content.error ? "none" : "block";
        if (error) error.style.display = content.error ? "block" : "none";
      }
    }

    if (active_modal) {
      active_modal.classList.add("clisha_modal_open");
    }
  } catch (error) {
    console.error("Error showing modal:", error);
  }
}

// SAFE URL PARSING
function parseQueryParam(url) {
  try {
    const query = {};
    const pairs = (url[0] === "?" ? url.substr(1) : url).split("&");
    for (let i = 0; i < pairs.length; i++) {
      const pair = pairs[i].split("=");
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
    }
    return query;
  } catch (error) {
    console.error("Error parsing query params:", error);
    return {};
  }
}

function initiateJourneyForm(link) {
  try {
    chrome.runtime.sendMessage({ trackForm: link }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending trackForm message:", chrome.runtime.lastError);
      }
    });
  } catch (error) {
    console.error("Error initiating journey form:", error);
  }
}

function timerInteraction() {
  let timer = `/templates/interaction_timer.html`;

  fetch(chrome.runtime.getURL(timer))
    .then((r) => r.text())
    .then((html) => {
      document.body.insertAdjacentHTML("beforeend", html);

      let warning = document.getElementById("clisha_warning");
      let clisha_timer = document.getElementById("clisha_timer");

      let timeValue = task?.google_search?.duration
        ? task?.google_search?.duration
        : task?.website_click?.duration
          ? task?.website_click?.duration
          : 45;

      if (Object.keys(currentJourney).length > 0) {
        timeValue = currentJourney?.step_interaction
          ? currentJourney.step_interaction.duration
          : 45;
      }

      let intervalId = setInterval(() => {
        try {
          let url = task.url ? task.url : "";
          if (Object.keys(currentJourney).length > 0) {
            url = currentJourney.link;
          }

          if (handshake(url) && document.visibilityState === "visible") {
            timeValue--;
            if (warning) warning.innerText = "Hello! Do not close or leave this window ";
            if (clisha_timer) clisha_timer.innerText = timeValue;

            if (timeValue === 0) {
              clearInterval(intervalId);
              if (task?.task_type === "journey" || task?.task_type === "search_journey") {
                return handleNextJourney();
              } else {
                return completeExtensionTask();
              }
            }
          }
        } catch (error) {
          console.error("Error in timer interval:", error);
          clearInterval(intervalId);
        }
      }, 1000);
    })
    .catch((error) => {
      console.error("Error loading timer template:", error);
    });
}

function multiChoiceInteraction() {
  const multichoice = `/templates/interaction_multichoice.html`;
  fetch(chrome.runtime.getURL(multichoice))
    .then((r) => r.text())
    .then((html) => {
      document.body.insertAdjacentHTML("beforeend", html);

      let question = document.querySelector("#multichoice-question"),
        option1 = document.querySelector("#option1"),
        option2 = document.querySelector("#option2"),
        option3 = document.querySelector("#option3"),
        option4 = document.querySelector("#option4"),
        option5 = document.querySelector("#option5");

      if (question && task.interaction) {
        question.innerHTML = task.interaction.question;
        if (option1) option1.innerHTML = task.interaction.option1;
        if (option2) option2.innerHTML = task.interaction.option2;

        if (task.interaction.option3 && option3) {
          document.querySelector(".option3").style.display = "block";
          option3.innerHTML = task.interaction.option3;
        }
        if (task.interaction.option4 && option4) {
          document.querySelector(".option4").style.display = "block";
          option4.innerHTML = task.interaction.option4;
        }
        if (task.interaction.option5 && option5) {
          document.querySelector(".option5").style.display = "block";
          option5.innerHTML = task.interaction.option5;
        }
      }
    })
    .catch((error) => {
      console.error("Error loading multichoice template:", error);
    });
}

function multiChoiceJourney() {
  let multichoice = `/templates/interaction_multichoice.html`;
  fetch(chrome.runtime.getURL(multichoice))
    .then((r) => r.text())
    .then((html) => {
      document.body.insertAdjacentHTML("beforeend", html);

      let question = document.querySelector("#multichoice-question"),
        option1 = document.querySelector("#option1"),
        option2 = document.querySelector("#option2"),
        option3 = document.querySelector("#option3"),
        option4 = document.querySelector("#option4"),
        option5 = document.querySelector("#option5");

      let options = [option1, option2, option3, option4, option5];

      if (question && currentJourney.step_interaction) {
        question.innerHTML = currentJourney.step_interaction.question;
        if (option1) option1.innerHTML = currentJourney.step_interaction.option1;
        if (option2) option2.innerHTML = currentJourney.step_interaction.option2;

        if (currentJourney.step_interaction.option3 && option3) {
          const option3Container = document.querySelector(".option3");
          if (option3Container) option3Container.style.display = "block";
          option3.innerHTML = currentJourney.step_interaction.option3;
        }
        if (currentJourney.step_interaction.option4 && option4) {
          const option4Container = document.querySelector(".option4");
          if (option4Container) option4Container.style.display = "block";
          option4.innerHTML = currentJourney.step_interaction.option4;
        }
        if (currentJourney.step_interaction.option5 && option5) {
          const option5Container = document.querySelector(".option5");
          if (option5Container) option5Container.style.display = "block";
          option5.innerHTML = currentJourney.step_interaction.option5;
        }

        // Add event listeners for option selection
        options.forEach((option, index) => {
          if (option) {
            let radioBtn = document.querySelector(`#option${index + 1}-radio`);
            if (radioBtn) {
              option.addEventListener("click", function (event) {
                if (event.target !== radioBtn) {
                  radioBtn.checked = true;
                }
                options.forEach((opt) => opt && opt.classList.remove("selected"));
                option.classList.add("selected");

                const submitBtn = document.querySelector("#clisha-submit-answer");
                if (submitBtn) submitBtn.disabled = false;
              });

              radioBtn.addEventListener("change", function () {
                options.forEach((opt) => opt && opt.classList.remove("selected"));
                option.classList.add("selected");

                const submitBtn = document.querySelector("#clisha-submit-answer");
                if (submitBtn) submitBtn.disabled = false;
              });
            }
          }
        });
      }
    })
    .catch((error) => {
      console.error("Error loading journey multichoice template:", error);
    });
}

function completeExtensionTask() {
  try {
    chrome.storage.sync.clear(function () {
      if (chrome.runtime.lastError) {
        console.error("Error clearing storage:", chrome.runtime.lastError);
        return;
      }

      const url = `${dashboardUrl}reward?t=${task.id}&p=${task.points}&c=${task?.interaction_b ? 20 : 10}&status=done&b=${task?.bonus_points}`;

      chrome.runtime.sendMessage({ completed: "true" }, (response) => {
        if (chrome.runtime.lastError) {
          console.error("Error sending completion message:", chrome.runtime.lastError);
        }
      });

      const features = "right=100,top=100,width=600,height=450";
      window.open(url, "_blank", features);

      const overlay = document.querySelector(".clisha_overlay"),
        float = document.querySelectorAll(".clisha_float");

      if (float.length) {
        float.forEach((f) => {
          f.style.display = "none";
        });
      }

      if (overlay) overlay.style.display = "none";
    });
  } catch (error) {
    console.error("Error completing extension task:", error);
  }
}

// ADD MISSING FUNCTIONS THAT ARE REFERENCED BUT NOT DEFINED
function handleNextJourney() {
  try {
    // Implementation for handling next journey step
    console.log("Handling next journey step");
    // Add your logic here
  } catch (error) {
    console.error("Error handling next journey:", error);
  }
}

function runGoogleSearch() {
  try {
    // Implementation for running Google search
    console.log("Running Google search");
    // Add your logic here
  } catch (error) {
    console.error("Error running Google search:", error);
  }
}

function runYoutubeSearch() {
  try {
    // Implementation for running YouTube search
    console.log("Running YouTube search");
    // Add your logic here
  } catch (error) {
    console.error("Error running YouTube search:", error);
  }
}

function runTiktokSearch() {
  try {
    // Implementation for running TikTok search
    console.log("Running TikTok search");
    // Add your logic here
  } catch (error) {
    console.error("Error running TikTok search:", error);
  }
}

function initExternalVideo(video) {
  try {
    // Implementation for initializing external video tracking
    console.log("Initializing external video tracking", video);
    // Add your logic here
  } catch (error) {
    console.error("Error initializing external video:", error);
  }
}

// Test connection with background script - SAFE MESSAGING
chrome.runtime.sendMessage({ test: "activate" }, response => {
  if (chrome.runtime.lastError) {
    console.error("Error connecting to background script:", chrome.runtime.lastError);
  } else {
    console.log(response?.status || "Connected to service worker");
  }
});