const mode = "RELEASE";
const baseUrl =
  mode === "RELEASE"
    ? "https://server.clisha.me/task"
    : "https://dev-server.clisha.me/task";
const dashboardUrl =
  mode === "RELEASE"
    ? "https://clisha.me/dashboard/"
    : "https://dev.clisha.me/dashboard/";

let formTracker = null,
  responseTracker = null;

//
async function fetchUrl(url) {
  if (url && url.includes("tk=") && url.includes("cd=")) {
    const item = await chrome.storage.sync.get("task");
    const urlParts = url.split("?");
    if (
      Object.keys(item).length === 0 &&
      Array.isArray(urlParts) &&
      urlParts.length > 0
    ) {
      const query = parseQueryParam(urlParts[1]);
      await getTaskDetails(query);
    } else {
      await reloadClishaTask();
    }
  }
}

// Helper function to safely send messages to content scripts
async function sendMessageSafely(tabId, message, retries = 3) {
  try {
    // Get tab info to check if it's ready
    const tab = await chrome.tabs.get(tabId);

    // Skip chrome:// and extension pages
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      return false;
    }

    // Only send to complete tabs
    if (tab.status !== 'complete') {
      return false;
    }

    // Try to send the message
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch (error) {
    if (retries > 0 && error.message.includes('Receiving end does not exist')) {
      // Wait a bit and retry
      await new Promise(resolve => setTimeout(resolve, 500));
      return sendMessageSafely(tabId, message, retries - 1);
    } else if (!error.message.includes('Receiving end does not exist')) {
      // Log other types of errors
      console.error(`Error sending message to tab ${tabId}:`, error);
    }
    return false;
  }
}

// Reload task function - handles task reactivation
async function reloadClishaTask() {
  try {
    const result = await chrome.storage.sync.get("task");
    const task = result.task;
    
    if (!task) {
      console.log("No task found to reload");
      return;
    }

    console.log("Reloading task:", task.task_type);
    
    // Get active tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) {
      console.error("No active tab found");
      return;
    }

    // Send appropriate activation message based on task type
    if (task.task_type === "google_search" || task.task_type === "search_journey") {
      const success = await sendMessageSafely(tabs[0].id, { 
        activateSearch: true, 
        task: task,
        step: result.step || 0
      });
      if (!success) {
        console.log("Failed to send search activation message");
      }
    } else if (task.task_type === "journey") {
      const success = await sendMessageSafely(tabs[0].id, { 
        activateJourney: true, 
        task: task,
        step: result.step || 1
      });
      if (!success) {
        console.log("Failed to send journey activation message");
      }
    }
  } catch (error) {
    console.error("Error reloading task:", error);
  }
}

// Full extension reload - only for critical system issues
function reloadExtension() {
  try {
    console.log("Performing full extension reload");
    chrome.runtime.reload();
  } catch (error) {
    console.error("Error reloading extension:", error);
  }
}

// Error handler with graceful degradation
async function handleCriticalError(error) {
  console.error("Critical error occurred:", error);
  try {
    // Try graceful task reload first
    await reloadClishaTask();
  } catch (reloadError) {
    console.error("Task reload failed, performing full extension reload:", reloadError);
    // Only use full reload as last resort
    reloadExtension();
  }
}

// Start Extension
chrome.tabs.onCreated.addListener(async function (activeInfo) {
  try {
    const tab = await chrome.tabs.get(activeInfo.id);
    const url = tab?.pendingUrl || tab?.url || false;

    if (!url) {
      // Wait until the tab actually has a URL
      chrome.tabs.onUpdated.addListener(async function listener(tabId, changeInfo, updatedTab) {
        if (tabId === tab.id && changeInfo.url) {
          // Do your task logic here
          await fetchUrl(changeInfo.url);
          chrome.tabs.onUpdated.removeListener(listener);
        }
      });
    } else {
      await fetchUrl(url);
    }
  } catch (error) {
    console.error("Error in tab creation listener:", error);
  }
});

// Listen for URL changes - Fixed storage check
chrome.storage.local.get("task").then(function (result) {
  // Fixed: Check if task actually exists in storage
  if (result && result.task) {
    chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
      // Only act on URL changes and when tab is complete
      if (changeInfo.url && tab.status === 'complete') {
        // Add delay to ensure page is ready
        setTimeout(async () => {
          const success = await sendMessageSafely(tabId, { appChange: true });
          if (!success) {
            console.log(`Failed to send appChange message to tab ${tabId}`);
          }
        }, 1000);
      }
    });
  }
});

function parseQueryParam(url) {
  const query = {};
  const pairs = (url[0] === "?" ? url.substr(1) : url).split("&");
  for (let i = 0; i < pairs.length; i++) {
    const pair = pairs[i].split("=");
    query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
  }
  return query;
}

async function getTaskDetails(query) {
  try {
    const response = await fetch(
      `${baseUrl}/clisha/task/${query.tk}?code=${query.cd}`
    );
    const data = await response.json();

    if (data?.status) {
      const task = data?.data;
      const step =
        task?.task_type === "journey" || task?.task_type === "search_journey"
          ? 1
          : 0;

      await chrome.storage.sync.set({ task: task, step: step });

      const tabs = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tabs[0]) {
        // Use safe messaging
        const success = await sendMessageSafely(tabs[0].id, { task: task, step: step });
        if (!success) {
          console.log("Failed to send task details to content script");
        }
      }

      const timer =
        task.task_type === "google_search"
          ? 20
          : task.task_type === "journey" || task.task_type === "search_journey"
            ? 40
            : 10;

      await chrome.alarms.create("deactivateTask", { delayInMinutes: timer });
    }
  } catch (err) {
    console.error("Error fetching task details:", err);
  }
}

async function deactivateExtensionTask() {
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1, 2],
    });

    await chrome.storage.sync.clear();
    console.log("Task deactivated successfully");
    
    // Notify content scripts that task is deactivated
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      await sendMessageSafely(tab.id, { taskDeactivated: true });
    }
    
  } catch (error) {
    console.error("Error in deactivateExtensionTask:", error);
    // Only reload extension if critical failure
    await handleCriticalError(error);
  }
}

// Message handling
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.test === "activate") {
    sendResponse({ status: "Background script active" });
    return true;
  }

  if (request.completed === "true") {
    console.log("Task completed");
    sendResponse({ received: true });
    return true;
  }

  if (request.reload === "true") {
    reloadClishaTask(); // Use task reload instead of full extension reload
    return true;
  }
  
  if (request.forceReload === "true") {
    reloadExtension(); // Only for critical system issues
    return true;
  }
  
  if (request.trackForm) {
    trackJourneyForm(request.trackForm);
    return true;
  }
  
  if (request.video === "vid_completed") {
    videoCompleted();
    return true;
  }
  
  return true;
});

async function videoCompleted() {
  setTimeout(async () => {
    try {
      const tabs = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tabs[0]) {
        // Use safe messaging
        const success = await sendMessageSafely(tabs[0].id, { vid_completed: true });
        if (!success) {
          console.log("Failed to send video completion message");
        }
      }
    } catch (error) {
      console.error("Error sending video completion message:", error);
    }
  }, 1000);
}

// Track Form Request using declarativeNetRequest - Fixed URL parsing
async function trackJourneyForm(link) {
  try {
    // Validate input
    if (!link || typeof link !== 'string') {
      throw new Error('Invalid link provided');
    }

    // Safe URL parsing - fixes CSP issue
    const url = new URL(link);
    const baseDomain = `${url.protocol}//${url.hostname}`;

    // Define rules for form submission tracking
    const rules = [
      {
        id: 1,
        priority: 1,
        action: { type: "allow" },
        condition: {
          urlFilter: baseDomain,
          resourceTypes: ["xmlhttprequest"],
          requestMethods: ["post", "put", "patch"],
        },
      },
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: rules,
    });

    // Listen for rule matches
    chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(
      async (info) => {
        if (info.request.method === "POST" && info.responseHeaders) {
          try {
            const tabs = await chrome.tabs.query({
              active: true,
              currentWindow: true,
            });
            if (tabs[0]) {
              // Use safe messaging
              const success = await sendMessageSafely(tabs[0].id, { form: true });
              if (!success) {
                console.log("Failed to send form tracking message");
              }
            }
          } catch (error) {
            console.error("Error sending form message:", error);
          }
        }
      }
    );
  } catch (error) {
    console.error("Error setting up form tracking:", error);
  }
}

// External messaging - Added error handling
chrome.runtime.onMessageExternal.addListener(
  (message, sender, sendResponse) => {
    try {
      if (message === "version") {
        sendResponse({
          type: "success",
          version: "1.0.3",
        });
        return true;
      }

      // Validate message structure
      if (!message || !message.sources || !sender.tab) {
        sendResponse({
          type: "error",
          message: "Invalid message or sender",
        });
        return true;
      }

      const sources = message.sources;
      const tab = sender.tab;

      // Use the screen capture API
      chrome.desktopCapture.chooseDesktopMedia(sources, tab, (streamId) => {
        if (!streamId) {
          sendResponse({
            type: "error",
            message: "Failed to get stream ID",
          });
        } else {
          sendResponse({
            type: "success",
            streamId: streamId,
          });
        }
      });
      return true;
    } catch (error) {
      console.error("Error in external message handler:", error);
      sendResponse({
        type: "error",
        message: "Internal error occurred",
      });
      return true;
    }
  }
);

// Handle alarm events
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "deactivateTask") {
    deactivateExtensionTask();
  }
});

// Cleanup on extension suspend
chrome.runtime.onSuspend.addListener(() => {
  formTracker = null;
  responseTracker = null;
});