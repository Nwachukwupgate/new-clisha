// Google Search
function runGoogleSearch() {
  if (domain[0] == google_url) {
    let query = parseQueryParam(currentUrl.href);
    query.q = query.q ? query.q : query.oq;
    let advance_type = task.advance_type;
    let is_advance_search = task?.task_type === advance_type ? false : true;

    if (!is_advance_search) {
      //color mark search title
      for (const hTag of document.querySelectorAll("h3")) {
        const cleanedTitle = task?.google_search?.title
          .trim()
          .replace(/[^\w\s]/gi, "");
        const cleanedTextContent = hTag.textContent
          .trim()
          .replace(/[^\w\s]/gi, "");
        if (cleanedTextContent == cleanedTitle) {
          console.log(hTag);
          let aTag = hTag.parentNode;
          let cUrl = aTag.getAttribute("href");
          if (
            task.url
              .replace("http://", "")
              .replace("https://", "")
              .replace("www.", "") ==
            cUrl
              .replace("http://", "")
              .replace("https://", "")
              .replace("www.", "")
          ) {
            hTag.style.backgroundColor = "yellow";
            hTag.textContent = `${hTag.textContent} 👈 `;
            let img = document.createElement("img");
            img.src = chrome.runtime.getURL("images/logo.png");
            img.style.height = "20px";
            img.style.width = "50px";
            hTag.append(img);
            hTag.style.color = "green";
            hTag.classList.add("noticeText");
          }
        }
      }
    }

    if (is_advance_search) {
      for (const Div of document.querySelectorAll("h3")) {
        const cleanedTitle = task?.google_search?.title
          .trim()
          .replace(/[^\w\s]/gi, "");
        const cleanedTextContent = Div.textContent
          .trim()
          .replace(/[^\w\s]/gi, "");

        if (cleanedTextContent == cleanedTitle) {
          let aTag = Div.parentNode;
          let cUrl = aTag.getAttribute("href");
          if (
            task.url
              .replace("http://", "")
              .replace("https://", "")
              .replace("www.", "") ==
            cUrl
              .replace("http://", "")
              .replace("https://", "")
              .replace("www.", "")
          ) {
            Div.textContent = `${Div.textContent} 👈 `;
            let img = document.createElement("img");
            img.src = chrome.runtime.getURL("images/logo.png");
            img.style.height = "20px";
            img.style.width = "50px";
            Div.append(img);
            Div.style.color = "green";
            Div.classList.add("noticeText");
          }
        }
      }
    }
    if (query.q) {
      actionOnGoogleSearch(query);
    } else if (query.tbm) {
      clishaGoogleAdvanceSearch(query);
    } else {
      return showModal(1, {
        head: `Please enter the copied Search Phrase into the Google Search Bar and hit enter`,
      });
    }
  } else {
    if (task?.task_type == "google_search") {
      actionOnGoogleSearchResult();
    } else {
      activateSearchJourneyTask();
    }
  }
}

function actionOnGoogleSearch(google) {
  if (domain[0] == google_url && google.q) {
    let url = currentUrl.href.split("?"),
      query = parseQueryParam(url[1]);

    let searched_phrase = query.q.replaceAll("+", " ").toLowerCase();

    if (clisha_search.search_phrase.toLowerCase() == searched_phrase) {
      clishaGoogleAdvanceSearch(query);
    } else {
      return showModal(2, {
        error: true,
        head: `Oops you have entered the wrong phrase please try again by entering "${clisha_search.search_phrase}"`,
      });
    }
  }
}

function clishaGoogleAdvanceSearch(query) {
  let advance_type = task.advance_type;
  let is_advance_search = task?.task_type == advance_type ? false : true;
  let google_search_tab = query.tbm;
  let is_google_search_tab = !((google_search_tab ?? null) === null);
  let prefered_tab = clisha_search.engine.split("_")[1];

  if (is_advance_search && advance_type != "campaign") {
    if (is_google_search_tab) {
      return showModal(1, {
        head: `Click ${clisha_search.title}`,
        body: `Please go through the ${prefered_tab} search results and click on the result with the website title "${clisha_search.title}"`,
      });
    } else {
      return showModal(1, {
        head: `Click the ${prefered_tab} tab`,
        body: `Please go through the Google tabs above or click on "All Filters"  button`,
      });
    }
  } else {
    return showModal(1, {
      head: `Click ${clisha_search.title}`,
      body: `Please go through the Google Search results and click on the result with the website title "${clisha_search.title}"`,
    });
  }
}

function actionOnGoogleSearchResult() {
  //&& document.referrer == 'https://www.google.com/'
  console.log(task);
  if (handshake(task.url)) {
    if (
      (task.interactionId &&
        task.interaction &&
        task.interaction?.interaction_type == "multichoice") ||
      task.interaction?.interaction_type == "multistep"
    ) {
      showModal(1, {
        head: `Great! Please read the question below and click on the answer button to answer it `,
        question: task.interaction ? task.interaction.question : "",
      });
      multiChoiceInteraction();
    } else {
      let external_video = ["tiktok", "youtube"]; //&& domain[0].includes(clisha_search.engine)
      if (external_video.includes(clisha_search.engine.toLowerCase())) {
        showModal(1, {
          head: `Kindly watch the video on this page. Watch up to 70% of the video to complete this task. Thanks`,
        });
        trackExternalVideo();
      } else if (task.advance_type != "google_video") {
        showModal(1, {
          head: `You have clicked on the right page! Please interact with this page until the timer runs out `,
        });
        timerInteraction();
      }
    }
  } else {
    showModal(2, {
      error: true,
      head: `You have clicked on the wrong page! Please go back to Google search result and click on  "${clisha_search.title}"`,
    });
  }
}

function runYoutubeSearch() {
  let url = new URL(window.location.href);
  let domain = url.hostname;
  let pathSegments = url.pathname.split("/");

  if (domain == "www.youtube.com" && pathSegments[1] == "watch") {
    actionOnYoutubeResult();
  } else {
    actionOnYoutubeSearch();
  }
}

function actionOnYoutubeSearch() {
  if (domain[0] == youtube_url && !currentUrl.href.includes("search_query=")) {
    return showModal(1, {
      head: `Please enter the copied Search Phrase into the Youtube Search Bar and hit enter`,
    });
  } else {
    let url = currentUrl.href.split("?"),
      query = parseQueryParam(url[1]);
    let searched_phrase = query.search_query.replaceAll("+", " ");
    if (clisha_search.search_phrase.toLowerCase() == searched_phrase) {
      return showModal(1, {
        head: `Click ${clisha_search.title}`,
        body: `Please go through this Youtube Search list and click on the result with the Video title "${clisha_search.title}"`,
      });
    } else {
      return showModal(2, {
        error: true,
        head: `Oops you have entered the wrong phrase please try again by entering "${clisha_search.search_phrase}"`,
      });
    }
  }
}

function actionOnYoutubeResult() {
  // console.log('Watching',  task.url);
  if (handshake(task.url)) {
    showModal(1, {
      head: `Kindly watch the video on this page. Watch up to 70% of the video to complete this task. Thanks`,
    });
    trackExternalVideo();
  } else {
    showModal(2, {
      error: true,
      head: `You have clicked on the wrong page! Please go back to the Youtube search result and click on  "${clisha_search.title}"`,
    });
  }
}

function runTiktokSearch() {
  let url = new URL(window.location.href);
  let domain = url.hostname;
  let pathSegments = url.pathname.split("/");

  if (domain == "www.tiktok.com" && pathSegments[2] == "video") {
    const dynamicSegment = urlSegments.slice(3).join("/");
    if (dynamicSegment === "video") {
      actionOnTiktokResult();
    } else {
      actionOnTiktokSearch();
    }
  } else {
    showModal(2, {
      error: true,
      head: "You have clicked on a wrong page! Please go to tiktok.com to begin this task",
    });
  }
}

function actionOnTiktokSearch() {
  if (domain[0] == tiktok_url && !currentUrl.href.includes("q=")) {
    return showModal(1, {
      head: `Please enter the copied Search Phrase into the Tiktok Search Bar and hit enter`,
    });
  } else {
    let url = currentUrl.href.split("?"),
      query = parseQueryParam(url[1]);

    let searched_phrase = query.q.replaceAll("+", " ").toLowerCase();

    if (clisha_search.search_phrase.toLowerCase() == searched_phrase) {
      return showModal(1, {
        head: `Click ${clisha_search.title}`,
        body: `Please go through this Tiktok Search list and click on the result with the website title "${clisha_search.title}"`,
      });
    } else {
      return showModal(2, {
        error: true,
        head: `Oops you have entered the wrong phrase please try again by entering "${clisha_search.search_phrase}"`,
      });
    }
  }
}

function actionOnTiktokResult() {
  if (handshake(task.url, "tiktok")) {
    showModal(1, {
      head: `Kindly watch the video on this page. Watch up to 70% of the video to complete this task. Thanks`,
    });
    trackExternalVideo();
  } else {
    showModal(2, {
      error: true,
      head: `You have clicked on the wrong page! Please go back to the Tiktok search result and click on  "${clisha_search.title}"`,
    });
  }
}
